import process from 'process';

console.log('test.js');
process.exit(0);